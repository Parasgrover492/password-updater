# Password-Generator-Updater
Generating a random password for a user and then allowing him to update it.
